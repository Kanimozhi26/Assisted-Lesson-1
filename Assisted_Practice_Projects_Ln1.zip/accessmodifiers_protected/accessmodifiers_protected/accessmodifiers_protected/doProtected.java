package accessmodifiers_protected;

public class doProtected extends doProtected1 {
	public static void main(String args[])
	{
		doProtected obj=new doProtected();
		System.out.println(obj.A(11));
	}
	

}
