package accessmodifiers_protected;

public class doProtected1 {
	protected int A(int a){
		return a;
	}
}
