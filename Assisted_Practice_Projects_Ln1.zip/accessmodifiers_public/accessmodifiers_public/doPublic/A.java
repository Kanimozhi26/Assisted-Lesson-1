package doPublic;
import doPublic1.*;
public class A {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B obj=new B();
		System.out.println("I AM ACCESSING PUBLIC INT FROM OTHER PACKAGE x= "+obj.x);

	}

}
