package doPublic1;

public class B {
	public int x=100;

}
